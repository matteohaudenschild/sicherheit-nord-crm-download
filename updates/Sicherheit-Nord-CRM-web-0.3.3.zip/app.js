const app = document.querySelector("#app");
const toastRegion = document.querySelector("#toast-region");

const APP_VERSION = "0.3.3";
const DEMO_DATA_KEY = "sn-crm-demo-data-v1";
const LEGACY_DATA_KEY = "sn-crm-prototype-v2";
const UPDATE_STATUS_KEY = "sn-crm-update-status-v1";
const UPDATE_MANIFEST_SOURCES = [
  {
    url: "https://matteohaudenschild.github.io/sicherheit-nord-crm-download/update-manifest-v4.json",
    parse: async (response) => response.json(),
  },
  {
    url: "https://raw.githubusercontent.com/matteohaudenschild/sicherheit-nord-crm-download/main/update-manifest-v4.json",
    parse: async (response) => response.json(),
  },
  {
    url: "https://api.github.com/repos/matteohaudenschild/sicherheit-nord-crm-download/contents/update-manifest-v4.json",
    parse: async (response) => {
      const payload = await response.json();
      const encoded = String(payload?.content || "").replace(/\s/g, "");
      if (!encoded) throw new Error("Update manifest content is missing.");
      return JSON.parse(decodeURIComponent(Array.from(atob(encoded), (character) => `%${character.charCodeAt(0).toString(16).padStart(2, "0")}`).join("")));
    },
  },
];
const UPDATE_CHECK_INTERVAL_MS = 15 * 60 * 1000;
const UPDATE_FETCH_TIMEOUT_MS = 10000;

const DEMO_USERS = {
  customer: {
    username: "kunde",
    password: "login",
    label: { de: "Kunde", en: "Customer" },
  },
  installer: {
    username: "errichter",
    password: "login",
    label: { de: "Errichter", en: "Installer" },
  },
  admin: {
    username: "admin",
    password: "login",
    label: { de: "Admin", en: "Admin" },
  },
};

const COPY = {
  de: {
    brand: "Sicherheit Nord",
    signIn: "Anmelden",
    username: "Benutzername",
    password: "Passwort",
    usernamePlaceholder: "Benutzername",
    passwordPlaceholder: "Passwort",
    forgotPassword: "Passwort vergessen?",
    settings: "Einstellungen",
    close: "Schließen",
    logout: "Abmelden",
    invalidCredentials: "Benutzername oder Passwort ist nicht korrekt.",
    forgotMessage: "Die Passwort-Wiederherstellung ist im Prototyp noch nicht mit einem Server verbunden.",
    version: "Version",
    customerArea: "Kundenbereich",
    installerArea: "Errichterbereich",
    adminArea: "Adminbereich",
    demo: "Demo",
    demoObject: "Demoobjekt Hamburg",
    alarmConnection: "Alarmaufschaltung · NSL",
    active: "Aktiv",
    yourAreas: "Ihre Bereiche",
    contracts: "Verträge",
    contractsSubtitle: "Vertragsdaten und Laufzeiten einsehen",
    measures: "Maßnahmenplan",
    measuresSubtitle: "Ablauf und Kontaktreihenfolge prüfen",
    plans: "Pläne",
    plansSubtitle: "Objekt- und Meldergruppenpläne öffnen",
    maintenance: "Wartung",
    maintenanceSubtitle: "Termine und Wartungsstand einsehen",
    account: "Mein Konto",
    accountSubtitle: "Kontaktdaten und Codewort bearbeiten",
    back: "Zurück",
    contractNumber: "Vertragsnummer",
    period: "Laufzeit",
    object: "Objekt",
    contacts: "Kontakte im Alarmfall",
    lastUpdated: "Letzte Aktualisierung",
    measuresFlow: "Vorgesehener Ablauf",
    planNotice: "Die angezeigten Abläufe sind fiktive Demo-Daten und enthalten keine echten Alarmdetails.",
    open: "Öffnen",
    documentNotConnected: "Demo-Dokument – noch nicht mit dem Dokumentenserver verbunden.",
    maintenanceLast: "Letzte Wartung",
    maintenanceNext: "Nächster Termin",
    scheduled: "Termin bestätigt",
    profileData: "Kontaktdaten",
    name: "Name",
    phone: "Telefonnummer",
    email: "E-Mail",
    codeword: "Codewort",
    codewordPlaceholder: "Neues Demo-Codewort (optional)",
    saveChanges: "Änderungen speichern",
    accountNotice: "Kontaktdaten werden in dieser Demo nur lokal gespeichert. Eine Admin-Benachrichtigung wird vorgemerkt, aber noch nicht versendet. Das eingegebene Demo-Codewort wird nicht gespeichert.",
    localSaved: "Änderung lokal gespeichert. Admin-Hinweis im Prototyp vorgemerkt.",
    invalidProfile: "Bitte prüfen Sie die eingegebenen Daten.",
    recentChanges: "Letzte Änderungen",
    noChanges: "Noch keine Änderungen in dieser Demo.",
    customers: "Kunden",
    searchCustomers: "Kunden durchsuchen",
    customerListIntro: "Fiktive Datensätze für die interne Vorführung",
    systems: "Anlagen",
    nextMaintenance: "Nächste Wartung",
    current: "Aktuell",
    dueSoon: "Bald fällig",
    issueOpen: "Störung offen",
    noResults: "Keine Demo-Kunden gefunden.",
    demoData: "Demo-Daten",
    signOutTitle: "Sitzung",
    updateTitle: "App-Update",
    updateCheck: "Jetzt prüfen",
    updateIdle: "Updates über WLAN und mobile Daten sind aktiv.",
    updateChecking: "Update wird geprüft …",
    updateCurrent: "Die App ist aktuell.",
    updateOffline: "Keine Internetverbindung. Die Prüfung startet automatisch, sobald du wieder online bist.",
    updateDownloading: "Update wird heruntergeladen …",
    updateInstalling: "Update wird installiert …",
    updateQueued: "Update ist für den nächsten Start vorbereitet.",
    updateFailed: "Update derzeit nicht erreichbar. Die App funktioniert weiter.",
  },
  en: {
    brand: "Sicherheit Nord",
    signIn: "Sign in",
    username: "Username",
    password: "Password",
    usernamePlaceholder: "Username",
    passwordPlaceholder: "Password",
    forgotPassword: "Forgot password?",
    settings: "Settings",
    close: "Close",
    logout: "Sign out",
    invalidCredentials: "The username or password is incorrect.",
    forgotMessage: "Password recovery is not connected to a server in this prototype yet.",
    version: "Version",
    customerArea: "Customer area",
    installerArea: "Installer area",
    adminArea: "Admin area",
    demo: "Demo",
    demoObject: "Hamburg demo site",
    alarmConnection: "Alarm connection · ARC",
    active: "Active",
    yourAreas: "Your areas",
    contracts: "Contracts",
    contractsSubtitle: "View contract data and terms",
    measures: "Response plan",
    measuresSubtitle: "Review workflow and contact order",
    plans: "Plans",
    plansSubtitle: "Open site and detector-zone plans",
    maintenance: "Maintenance",
    maintenanceSubtitle: "View appointments and maintenance status",
    account: "My account",
    accountSubtitle: "Edit contact details and codeword",
    back: "Back",
    contractNumber: "Contract number",
    period: "Term",
    object: "Site",
    contacts: "Emergency contacts",
    lastUpdated: "Last updated",
    measuresFlow: "Planned workflow",
    planNotice: "The workflows shown are fictional demo data and contain no real alarm details.",
    open: "Open",
    documentNotConnected: "Demo document – not connected to the document server yet.",
    maintenanceLast: "Last maintenance",
    maintenanceNext: "Next appointment",
    scheduled: "Appointment confirmed",
    profileData: "Contact details",
    name: "Name",
    phone: "Phone number",
    email: "Email",
    codeword: "Codeword",
    codewordPlaceholder: "New demo codeword (optional)",
    saveChanges: "Save changes",
    accountNotice: "Contact details are stored locally in this demo only. An admin notification is queued but not sent yet. The entered demo codeword is not stored.",
    localSaved: "Change saved locally. Admin notice queued in the prototype.",
    invalidProfile: "Please check the entered data.",
    recentChanges: "Recent changes",
    noChanges: "No changes in this demo yet.",
    customers: "Customers",
    searchCustomers: "Search customers",
    customerListIntro: "Fictional records for the internal demonstration",
    systems: "Systems",
    nextMaintenance: "Next maintenance",
    current: "Current",
    dueSoon: "Due soon",
    issueOpen: "Issue open",
    noResults: "No demo customers found.",
    demoData: "Demo data",
    signOutTitle: "Session",
    updateTitle: "App update",
    updateCheck: "Check now",
    updateIdle: "Updates over Wi-Fi and mobile data are active.",
    updateChecking: "Checking for an update …",
    updateCurrent: "The app is up to date.",
    updateOffline: "No internet connection. The update check will start automatically when you are online again.",
    updateDownloading: "Downloading update …",
    updateInstalling: "Installing update …",
    updateQueued: "Update is prepared for the next launch.",
    updateFailed: "Update is currently unavailable. The app will keep working.",
  },
};

const ICON_PATHS = {
  settings: '<path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.09a2 2 0 0 1 1 1.74v.5a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.38a2 2 0 0 0-.73-2.73l-.15-.09a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2Z"></path><circle cx="12" cy="12" r="3"></circle>',
  user: '<path d="M20 21a8 8 0 0 0-16 0"></path><circle cx="12" cy="7" r="4"></circle>',
  lock: '<rect width="16" height="11" x="4" y="10" rx="2"></rect><path d="M8 10V7a4 4 0 0 1 8 0v3"></path>',
  file: '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8Z"></path><path d="M14 2v6h6"></path><path d="M8 13h8M8 17h6"></path>',
  shield: '<path d="M20 13c0 5-3.5 7.5-8 9-4.5-1.5-8-4-8-9V5l8-3 8 3Z"></path><path d="m9 12 2 2 4-4"></path>',
  folder: '<path d="M3 6a2 2 0 0 1 2-2h5l2 2h7a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2Z"></path>',
  wrench: '<path d="M14.7 6.3a4 4 0 0 0-5-5L7.4 3.6l3 3L12.7 4a4 4 0 0 0 2 5L6 17.7a2.1 2.1 0 1 0 3 3l8.7-8.7a4 4 0 0 0 5-2l-3 3-3-3 3-3a4 4 0 0 0-5-1.7Z"></path>',
  chevron: '<path d="m9 18 6-6-6-6"></path>',
  arrowLeft: '<path d="m15 18-6-6 6-6"></path>',
  close: '<path d="M18 6 6 18M6 6l12 12"></path>',
  logout: '<path d="M10 17l5-5-5-5"></path><path d="M15 12H3"></path><path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4"></path>',
  building: '<rect width="16" height="20" x="4" y="2" rx="2"></rect><path d="M9 22v-4h6v4M8 6h.01M16 6h.01M8 10h.01M16 10h.01M8 14h.01M16 14h.01"></path>',
  search: '<circle cx="11" cy="11" r="8"></circle><path d="m21 21-4.3-4.3"></path>',
  calendar: '<rect width="18" height="18" x="3" y="4" rx="2"></rect><path d="M16 2v4M8 2v4M3 10h18"></path>',
  check: '<path d="m20 6-11 11-5-5"></path>',
  alert: '<path d="M10.3 2.9 1.8 17a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 2.9a2 2 0 0 0-3.4 0Z"></path><path d="M12 9v4M12 17h.01"></path>',
};

const DEFAULT_PROFILE = {
  name: "Max Mustermann (Demo)",
  phone: "+49 000 000000",
  email: "max.mustermann@demo.invalid",
};

const CUSTOMER_CONTENT = {
  contracts: [
    { title: { de: "Alarmaufschaltung", en: "Alarm connection" }, number: "SN-DEMO-24018", period: "01.01.2026 – 31.12.2026", object: { de: "Demoobjekt Hamburg", en: "Hamburg demo site" } },
    { title: { de: "Interventionsdienst", en: "Intervention service" }, number: "SN-DEMO-24019", period: "01.01.2026 – 31.12.2026", object: { de: "Demoobjekt Hamburg", en: "Hamburg demo site" } },
  ],
  measures: [
    { de: "Alarmannahme und Prüfung durch die NSL", en: "Alarm receipt and verification by the ARC" },
    { de: "Kontaktreihenfolge des Kunden abarbeiten", en: "Process the customer's contact order" },
    { de: "Bei Bedarf Interventionsdienst beauftragen", en: "Dispatch the intervention service if required" },
    { de: "Ereignis und Maßnahmen dokumentieren", en: "Document the event and response" },
  ],
  plans: [
    { title: { de: "Objektübersicht", en: "Site overview" }, meta: "PDF · Demo · 24.09.2026" },
    { title: { de: "Meldergruppenplan", en: "Detector-zone plan" }, meta: "PDF · Demo · 24.09.2026" },
    { title: { de: "Flucht- und Rettungsplan", en: "Escape and rescue plan" }, meta: "PDF · Demo · 12.08.2026" },
  ],
};

const INSTALLER_CUSTOMERS = [
  { name: "Demo Logistik Nord GmbH", city: "Hamburg", number: "K-DEMO-1001", systems: 2, maintenance: "18.10.2026", status: "current" },
  { name: "Musterwerk Kiel GmbH", city: "Kiel", number: "K-DEMO-1002", systems: 1, maintenance: "08.10.2026", status: "dueSoon" },
  { name: "Beispielmarkt Neumünster", city: "Neumünster", number: "K-DEMO-1003", systems: 3, maintenance: "21.11.2026", status: "current" },
  { name: "Nordhafen Demo GmbH", city: "Lübeck", number: "K-DEMO-1004", systems: 1, maintenance: { de: "Prüfung erforderlich", en: "Inspection required" }, status: "issueOpen" },
  { name: "Musterbüro Flensburg", city: "Flensburg", number: "K-DEMO-1005", systems: 2, maintenance: "03.12.2026", status: "current" },
];

const state = {
  language: "de",
  role: null,
  username: "",
  view: "login",
  customerQuery: "",
  profile: { ...DEFAULT_PROFILE },
  activity: [],
  updateStatus: "updateIdle",
};

function t(key) {
  return COPY[state.language]?.[key] || COPY.de[key] || key;
}

function localized(value) {
  if (!value || typeof value !== "object") return String(value ?? "");
  return value[state.language] || value.de || "";
}

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function icon(name, className = "icon") {
  return `<svg class="${escapeHtml(className)}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">${ICON_PATHS[name] || ICON_PATHS.file}</svg>`;
}

function readStoredData() {
  try {
    localStorage.removeItem("sn-crm-preferences-v1");
    localStorage.removeItem(LEGACY_DATA_KEY);
  } catch {
    // Legacy cleanup is optional when storage is unavailable.
  }

  try {
    const savedUpdateStatus = JSON.parse(localStorage.getItem(UPDATE_STATUS_KEY) || "null");
    if (typeof savedUpdateStatus?.status === "string" && COPY.de[savedUpdateStatus.status]) {
      state.updateStatus = savedUpdateStatus.status;
    }
  } catch {
    // Update diagnostics are optional.
  }

  try {
    const saved = JSON.parse(localStorage.getItem(DEMO_DATA_KEY) || "null");
    if (saved?.profile && typeof saved.profile === "object") {
      for (const key of Object.keys(DEFAULT_PROFILE)) {
        if (typeof saved.profile[key] === "string" && saved.profile[key].length <= 120) state.profile[key] = saved.profile[key];
      }
    }
    if (Array.isArray(saved?.activity)) {
      const allowedFields = new Set(["name", "phone", "email", "codeword"]);
      state.activity = saved.activity
        .filter((entry) => entry && typeof entry.date === "string" && Array.isArray(entry.fields))
        .map((entry) => ({ date: entry.date, fields: entry.fields.filter((field) => allowedFields.has(field)) }))
        .filter((entry) => entry.fields.length > 0)
        .slice(0, 8);
    }
  } catch {
    // Demo data is optional.
  }
}

function saveDemoData() {
  try {
    localStorage.setItem(DEMO_DATA_KEY, JSON.stringify({ profile: state.profile, activity: state.activity }));
  } catch {
    // Local demo persistence is optional.
  }
}

function applyAppAppearance() {
  document.documentElement.lang = "de";
  document.documentElement.removeAttribute("data-theme");
  document.querySelector('meta[name="theme-color"]')?.setAttribute("content", "#000000");
}

function logoMarkup(extraClass = "") {
  return `<img class="brand-logo ${escapeHtml(extraClass)}" src="./app-icon-1024.png" alt="Sicherheit Nord" width="1024" height="1024" />`;
}

function settingsMarkup() {
  return `
    <dialog id="settings-dialog" aria-labelledby="settings-title">
      <div class="dialog-head">
        <h2 id="settings-title">${escapeHtml(t("settings"))}</h2>
        <button class="icon-button" type="button" data-action="close-settings" aria-label="${escapeHtml(t("close"))}">${icon("close")}</button>
      </div>
      <div class="dialog-body">
        <section class="settings-update" aria-labelledby="update-title">
          <div>
            <p id="update-title">${escapeHtml(t("updateTitle"))}</p>
            <small id="update-status">${escapeHtml(t(state.updateStatus))}</small>
          </div>
          <button class="secondary-button" type="button" data-action="check-update">${escapeHtml(t("updateCheck"))}</button>
          <span>${escapeHtml(t("version"))} ${APP_VERSION}</span>
        </section>
        ${state.role ? `<div class="settings-session"><p>${escapeHtml(t("signOutTitle"))}</p><button class="settings-logout" type="button" data-action="logout">${icon("logout")}<span>${escapeHtml(t("logout"))}</span></button></div>` : ""}
      </div>
    </dialog>
  `;
}

function roleLabel(role) {
  return DEMO_USERS[role]?.label?.[state.language] || role;
}

function renderLogin(errorMessage = "", usernameValue = "") {
  applyAppAppearance();
  state.view = "login";
  document.title = `${t("brand")} · ${t("signIn")}`;
  app.innerHTML = `
    <main class="login-page">
      <div class="login-topbar">
        <button class="login-settings icon-button icon-button-on-dark" type="button" data-action="settings" aria-label="${escapeHtml(t("settings"))}">${icon("settings")}</button>
      </div>
      <section class="login-shell" aria-labelledby="login-title">
        ${logoMarkup("login-logo")}
        <h1 id="login-title" class="visually-hidden">${escapeHtml(t("signIn"))}</h1>
        <form id="login-form" class="login-form" novalidate>
          <div class="login-field">
            <label class="visually-hidden" for="username">${escapeHtml(t("username"))}</label>
            <span class="field-icon">${icon("user")}</span>
            <input id="username" name="username" type="text" autocomplete="username" autocapitalize="none" spellcheck="false" placeholder="${escapeHtml(t("usernamePlaceholder"))}" value="${escapeHtml(usernameValue)}" required />
          </div>
          <div class="login-field">
            <label class="visually-hidden" for="password">${escapeHtml(t("password"))}</label>
            <span class="field-icon">${icon("lock")}</span>
            <input id="password" name="password" type="password" autocomplete="current-password" placeholder="${escapeHtml(t("passwordPlaceholder"))}" required />
          </div>
          <button class="forgot-link" type="button" data-action="forgot-password">${escapeHtml(t("forgotPassword"))}</button>
          ${errorMessage ? `<p class="form-error" role="alert">${escapeHtml(errorMessage)}</p>` : ""}
          <button class="primary-button" type="submit">${escapeHtml(t("signIn"))}</button>
        </form>
      </section>
      <footer class="login-version">${escapeHtml(t("version"))} ${APP_VERSION}</footer>
    </main>
    ${settingsMarkup()}
  `;
}

function workspaceHeader() {
  const area = state.role === "installer" ? t("installerArea") : state.role === "admin" ? t("adminArea") : t("customerArea");
  return `
    <header class="workspace-header">
      <div class="workspace-brand">
        ${logoMarkup("workspace-logo")}
        <div><strong>${escapeHtml(t("brand"))}</strong><span>${escapeHtml(area)} · ${escapeHtml(t("demo"))}</span></div>
      </div>
      <button class="icon-button icon-button-on-dark" type="button" data-action="settings" aria-label="${escapeHtml(t("settings"))}">${icon("settings")}</button>
    </header>
  `;
}

function featureRow(view, iconName, title, subtitle) {
  return `
    <button class="feature-row" type="button" data-action="navigate" data-view="${escapeHtml(view)}">
      <span class="feature-icon">${icon(iconName)}</span>
      <span class="feature-copy"><strong>${escapeHtml(title)}</strong><small>${escapeHtml(subtitle)}</small></span>
      <span class="feature-arrow">${icon("chevron")}</span>
    </button>
  `;
}

function detailHeading(title, subtitle = "") {
  return `
    <div class="detail-heading">
      <button class="back-button" type="button" data-action="back-customer" aria-label="${escapeHtml(t("back"))}">${icon("arrowLeft")}<span>${escapeHtml(t("back"))}</span></button>
      <h1 id="page-title" tabindex="-1">${escapeHtml(title)}</h1>
      ${subtitle ? `<p>${escapeHtml(subtitle)}</p>` : ""}
    </div>
  `;
}

function renderCustomerHome() {
  return `
    <div class="workspace-content">
      <div class="page-heading">
        <p>${escapeHtml(t("customerArea"))}</p>
        <h1 id="page-title" tabindex="-1">${escapeHtml(state.profile.name.replace(" (Demo)", ""))}</h1>
      </div>
      <section class="object-status" aria-label="${escapeHtml(t("demoObject"))}">
        <div class="object-status-icon">${icon("shield")}</div>
        <div class="object-status-copy"><span class="demo-badge">${escapeHtml(t("demo"))}</span><strong>${escapeHtml(t("demoObject"))}</strong><small>${escapeHtml(t("alarmConnection"))}</small></div>
        <span class="status-pill status-good">${escapeHtml(t("active"))}</span>
      </section>
      <h2 class="section-title">${escapeHtml(t("yourAreas"))}</h2>
      <nav class="feature-list" aria-label="${escapeHtml(t("yourAreas"))}">
        ${featureRow("customer-contracts", "file", t("contracts"), t("contractsSubtitle"))}
        ${featureRow("customer-measures", "shield", t("measures"), t("measuresSubtitle"))}
        ${featureRow("customer-plans", "folder", t("plans"), t("plansSubtitle"))}
        ${featureRow("customer-maintenance", "wrench", t("maintenance"), t("maintenanceSubtitle"))}
        ${featureRow("customer-account", "user", t("account"), t("accountSubtitle"))}
      </nav>
    </div>
  `;
}

function renderCustomerContracts() {
  return `
    <div class="workspace-content">
      ${detailHeading(t("contracts"), t("contractsSubtitle"))}
      <div class="record-list">
        ${CUSTOMER_CONTENT.contracts.map((contract) => `
          <article class="record-card">
            <div class="record-head">
              <div class="record-icon">${icon("file")}</div>
              <div><span class="demo-badge">${escapeHtml(t("demo"))}</span><h2>${escapeHtml(localized(contract.title))}</h2></div>
              <span class="status-pill status-good">${escapeHtml(t("active"))}</span>
            </div>
            <dl class="data-list">
              <div><dt>${escapeHtml(t("contractNumber"))}</dt><dd>${escapeHtml(contract.number)}</dd></div>
              <div><dt>${escapeHtml(t("period"))}</dt><dd>${escapeHtml(contract.period)}</dd></div>
              <div><dt>${escapeHtml(t("object"))}</dt><dd>${escapeHtml(localized(contract.object))}</dd></div>
            </dl>
          </article>`).join("")}
      </div>
    </div>
  `;
}

function renderCustomerMeasures() {
  return `
    <div class="workspace-content">
      ${detailHeading(t("measures"), t("measuresSubtitle"))}
      <section class="record-card compact-card">
        <span class="demo-badge">${escapeHtml(t("demoData"))}</span>
        <dl class="data-list overview-list">
          <div><dt>${escapeHtml(t("object"))}</dt><dd>${escapeHtml(t("demoObject"))}</dd></div>
          <div><dt>${escapeHtml(t("contacts"))}</dt><dd>2 ${state.language === "en" ? "demo contacts" : "Demo-Ansprechpersonen"}</dd></div>
          <div><dt>${escapeHtml(t("lastUpdated"))}</dt><dd>24.09.2026</dd></div>
        </dl>
      </section>
      <h2 class="section-title">${escapeHtml(t("measuresFlow"))}</h2>
      <ol class="step-list">${CUSTOMER_CONTENT.measures.map((step, index) => `<li><span>${index + 1}</span><p>${escapeHtml(localized(step))}</p></li>`).join("")}</ol>
      <p class="information-note">${icon("alert")}<span>${escapeHtml(t("planNotice"))}</span></p>
    </div>
  `;
}

function renderCustomerPlans() {
  return `
    <div class="workspace-content">
      ${detailHeading(t("plans"), t("plansSubtitle"))}
      <div class="document-list">
        ${CUSTOMER_CONTENT.plans.map((plan) => `
          <article class="document-row">
            <span class="document-icon">${icon("file")}</span>
            <div><span class="demo-badge">${escapeHtml(t("demo"))}</span><h2>${escapeHtml(localized(plan.title))}</h2><p>${escapeHtml(plan.meta)}</p></div>
            <button class="small-action" type="button" data-action="demo-document" aria-label="${escapeHtml(`${t("open")}: ${localized(plan.title)}`)}">${escapeHtml(t("open"))}</button>
          </article>`).join("")}
      </div>
    </div>
  `;
}

function renderCustomerMaintenance() {
  return `
    <div class="workspace-content">
      ${detailHeading(t("maintenance"), t("maintenanceSubtitle"))}
      <section class="maintenance-panel">
        <span class="demo-badge">${escapeHtml(t("demoData"))}</span>
        <div class="maintenance-row"><span class="maintenance-icon">${icon("check")}</span><div><small>${escapeHtml(t("maintenanceLast"))}</small><strong>18.04.2026</strong><p>${state.language === "en" ? "Alarm system · completed" : "Gefahrenmeldeanlage · durchgeführt"}</p></div></div>
        <div class="timeline-line" aria-hidden="true"></div>
        <div class="maintenance-row"><span class="maintenance-icon is-next">${icon("calendar")}</span><div><small>${escapeHtml(t("maintenanceNext"))}</small><strong>18.10.2026 · 09:00</strong><p>${escapeHtml(t("scheduled"))} · ${escapeHtml(t("demo"))}</p></div></div>
      </section>
    </div>
  `;
}

function activityFieldLabel(field) {
  return t(field) || field;
}

function renderCustomerAccount() {
  return `
    <div class="workspace-content">
      ${detailHeading(t("account"), t("accountSubtitle"))}
      <p class="information-note account-note">${icon("alert")}<span>${escapeHtml(t("accountNotice"))}</span></p>
      <form id="account-form" class="account-form">
        <h2>${escapeHtml(t("profileData"))}</h2>
        <label for="profile-name">${escapeHtml(t("name"))}</label>
        <input id="profile-name" name="name" type="text" autocomplete="name" maxlength="80" value="${escapeHtml(state.profile.name)}" required />
        <label for="profile-phone">${escapeHtml(t("phone"))}</label>
        <input id="profile-phone" name="phone" type="tel" autocomplete="tel" maxlength="30" value="${escapeHtml(state.profile.phone)}" required />
        <label for="profile-email">${escapeHtml(t("email"))}</label>
        <input id="profile-email" name="email" type="email" autocomplete="email" maxlength="120" value="${escapeHtml(state.profile.email)}" required />
        <label for="profile-codeword">${escapeHtml(t("codeword"))}</label>
        <input id="profile-codeword" name="codeword" type="password" autocomplete="off" maxlength="60" placeholder="${escapeHtml(t("codewordPlaceholder"))}" />
        <button class="primary-button" type="submit">${escapeHtml(t("saveChanges"))}</button>
      </form>
      <section class="activity-section">
        <h2>${escapeHtml(t("recentChanges"))}</h2>
        ${state.activity.length ? `<ul class="activity-list">${state.activity.map((entry) => `<li><span class="activity-dot"></span><div><strong>${entry.fields.map(activityFieldLabel).map(escapeHtml).join(", ")}</strong><small>${escapeHtml(new Date(entry.date).toLocaleString(state.language === "en" ? "en-GB" : "de-DE"))}</small></div></li>`).join("")}</ul>` : `<p class="empty-note">${escapeHtml(t("noChanges"))}</p>`}
      </section>
    </div>
  `;
}

function installerStatus(customer) {
  const className = customer.status === "current" ? "status-good" : customer.status === "dueSoon" ? "status-warning" : "status-danger";
  return `<span class="status-pill ${className}">${escapeHtml(t(customer.status))}</span>`;
}

function installerCustomerRows() {
  const query = state.customerQuery.trim().toLocaleLowerCase(state.language === "en" ? "en" : "de");
  const matches = INSTALLER_CUSTOMERS.filter((customer) => `${customer.name} ${customer.city} ${customer.number}`.toLocaleLowerCase().includes(query));
  if (!matches.length) return `<p class="empty-note list-empty">${escapeHtml(t("noResults"))}</p>`;
  return matches.map((customer) => {
    const systemsLabel = customer.systems === 1 ? (state.language === "en" ? "system" : "Anlage") : t("systems");
    return `
    <article class="customer-row">
      <span class="customer-icon">${icon("building")}</span>
      <div class="customer-copy">
        <div class="customer-name-line"><h2>${escapeHtml(customer.name)}</h2><span class="demo-badge">${escapeHtml(t("demo"))}</span></div>
        <p>${escapeHtml(customer.number)} · ${escapeHtml(customer.city)}</p>
        <small>${customer.systems} ${escapeHtml(systemsLabel)} · ${escapeHtml(t("nextMaintenance"))}: ${escapeHtml(localized(customer.maintenance))}</small>
      </div>
      ${installerStatus(customer)}
    </article>`;
  }).join("");
}

function renderInstallerCustomers() {
  return `
    <div class="workspace-content installer-content">
      <div class="page-heading">
        <p>${escapeHtml(t("installerArea"))}</p>
        <h1 id="page-title" tabindex="-1">${escapeHtml(t("customers"))}</h1>
        <span>${escapeHtml(t("customerListIntro"))}</span>
      </div>
      <label class="search-field" for="customer-search"><span>${icon("search")}</span><input id="customer-search" type="search" autocomplete="off" placeholder="${escapeHtml(t("searchCustomers"))}" value="${escapeHtml(state.customerQuery)}" /></label>
      <div id="installer-customer-list" class="customer-list">${installerCustomerRows()}</div>
    </div>
  `;
}

function renderAdminHome() {
  return `
    <div class="workspace-content admin-content">
      <h1 id="page-title" class="visually-hidden" tabindex="-1">${escapeHtml(t("adminArea"))}</h1>
    </div>
  `;
}

function customerViewMarkup() {
  if (state.view === "customer-contracts") return renderCustomerContracts();
  if (state.view === "customer-measures") return renderCustomerMeasures();
  if (state.view === "customer-plans") return renderCustomerPlans();
  if (state.view === "customer-maintenance") return renderCustomerMaintenance();
  if (state.view === "customer-account") return renderCustomerAccount();
  return renderCustomerHome();
}

function renderWorkspace() {
  applyAppAppearance();
  document.title = `${roleLabel(state.role)} · ${t("brand")}`;
  const content = state.role === "installer"
    ? renderInstallerCustomers()
    : state.role === "admin"
      ? renderAdminHome()
      : customerViewMarkup();
  app.innerHTML = `<main class="workspace-page">${workspaceHeader()}${content}</main>${settingsMarkup()}`;
}

function showToast(message) {
  if (!toastRegion) return;
  toastRegion.innerHTML = `<div class="toast" role="status">${escapeHtml(message)}</div>`;
  window.setTimeout(() => { toastRegion.innerHTML = ""; }, 3800);
}

function openSettings() {
  const dialog = document.getElementById("settings-dialog");
  if (dialog && typeof dialog.showModal === "function") dialog.showModal();
}

function closeSettings() {
  document.getElementById("settings-dialog")?.close();
}

function homeViewForRole(role) {
  if (role === "installer") return "installer-customers";
  if (role === "admin") return "admin-home";
  return "customer-home";
}

function attemptLogin(form) {
  const data = new FormData(form);
  const username = String(data.get("username") || "").trim();
  const password = String(data.get("password") || "");
  const accountEntry = Object.entries(DEMO_USERS).find(([, account]) => account.username === username && account.password === password);
  if (!username || !password || !accountEntry) {
    renderLogin(t("invalidCredentials"), username);
    window.requestAnimationFrame(() => document.getElementById(username ? "password" : "username")?.focus());
    return;
  }
  state.role = accountEntry[0];
  state.username = username;
  state.view = homeViewForRole(state.role);
  history.pushState({ loggedIn: true, view: state.view }, "");
  renderWorkspace();
}

function logout() {
  state.role = null;
  state.username = "";
  state.view = "login";
  state.customerQuery = "";
  history.replaceState({ loggedIn: false }, "");
  renderLogin();
}

function navigateTo(view) {
  if (!state.role) return;
  if (state.role === "installer") state.view = "installer-customers";
  else if (state.role === "admin") state.view = "admin-home";
  else state.view = String(view || "").startsWith("customer-") ? view : "customer-home";
  history.pushState({ loggedIn: true, view: state.view }, "");
  renderWorkspace();
  window.requestAnimationFrame(() => document.getElementById("page-title")?.focus());
}

function backToCustomerHome() {
  if (state.role !== "customer") return;
  if (state.view !== "customer-home") {
    history.back();
    return;
  }
  state.view = "customer-home";
  history.replaceState({ loggedIn: true, view: state.view }, "");
  renderWorkspace();
}

function saveAccount(form) {
  const data = new FormData(form);
  const nextProfile = {
    name: String(data.get("name") || "").trim(),
    phone: String(data.get("phone") || "").trim(),
    email: String(data.get("email") || "").trim(),
  };
  const codeword = String(data.get("codeword") || "").trim();
  const validPhone = /^[+0-9 ()/\-]{5,30}$/.test(nextProfile.phone);
  const emailInput = form.querySelector('input[name="email"]');
  if (!nextProfile.name || !validPhone || !emailInput?.checkValidity() || (codeword && codeword.length < 4)) {
    showToast(t("invalidProfile"));
    return;
  }
  const fields = Object.keys(nextProfile).filter((key) => nextProfile[key] !== state.profile[key]);
  if (codeword) fields.push("codeword");
  if (!fields.length) {
    showToast(t("localSaved"));
    return;
  }
  state.profile = nextProfile;
  state.activity.unshift({ date: new Date().toISOString(), fields });
  state.activity = state.activity.slice(0, 8);
  saveDemoData();
  renderWorkspace();
  showToast(t("localSaved"));
}

function compareVersions(left, right) {
  const a = String(left).split(".").map((part) => Number.parseInt(part, 10) || 0);
  const b = String(right).split(".").map((part) => Number.parseInt(part, 10) || 0);
  const length = Math.max(a.length, b.length);
  for (let index = 0; index < length; index += 1) {
    if ((a[index] || 0) > (b[index] || 0)) return 1;
    if ((a[index] || 0) < (b[index] || 0)) return -1;
  }
  return 0;
}

let updateCheckRunning = false;
let lastUpdateCheck = 0;
let nativePlugins = null;

function getNativePlugins() {
  const capacitor = window.Capacitor;
  if (!capacitor?.isNativePlatform?.()) return null;
  if (!nativePlugins) {
    const LiveUpdate = capacitor.Plugins?.LiveUpdate || capacitor.registerPlugin?.("LiveUpdate");
    const Network = capacitor.Plugins?.Network || capacitor.registerPlugin?.("Network");
    if (!LiveUpdate || !Network) return null;
    nativePlugins = { LiveUpdate, Network };
  }
  return nativePlugins;
}

function setUpdateStatus(status, error = null) {
  state.updateStatus = COPY.de[status] ? status : "updateFailed";
  try {
    localStorage.setItem(UPDATE_STATUS_KEY, JSON.stringify({ status: state.updateStatus, checkedAt: new Date().toISOString() }));
  } catch {
    // Diagnostics must never prevent the app from starting.
  }
  const statusElement = document.getElementById("update-status");
  if (statusElement) statusElement.textContent = t(state.updateStatus);
  if (error) console.error("Sicherheit Nord live update:", error);
}

function delay(milliseconds) {
  return new Promise((resolve) => window.setTimeout(resolve, milliseconds));
}

async function fetchWithTimeout(url) {
  const controller = new AbortController();
  const timeout = window.setTimeout(() => controller.abort(), UPDATE_FETCH_TIMEOUT_MS);
  try {
    return await fetch(url, { cache: "no-store", headers: { Accept: "application/json" }, signal: controller.signal });
  } finally {
    window.clearTimeout(timeout);
  }
}

function isValidUpdateManifest(manifest) {
  return (
    manifest?.schema === 1
    && manifest?.appId === "de.sicherheitnord.crm.demo"
    && /^\d+\.\d+\.\d+$/.test(manifest?.latestVersion || "")
    && Number.isInteger(Number(manifest?.nativeVersionCode))
    && Number(manifest.nativeVersionCode) > 0
    && /^sn-crm-web-\d+\.\d+\.\d+-[a-f0-9]{8,64}$/i.test(manifest?.bundleId || "")
    && /^https:\/\//i.test(manifest?.bundleUrl || "")
    && /^[a-f0-9]{64}$/i.test(manifest?.sha256 || "")
  );
}

async function fetchManifestSource(source, sourceIndex) {
  let lastError = new Error("Update manifest source is unavailable.");
  for (let attempt = 0; attempt < 2; attempt += 1) {
    try {
      const separator = source.url.includes("?") ? "&" : "?";
      const cacheBuster = `sn=${Date.now()}-${sourceIndex}-${attempt}`;
      const response = await fetchWithTimeout(`${source.url}${separator}${cacheBuster}`);
      if (!response.ok) throw new Error(`Manifest request failed with HTTP ${response.status}.`);
      const manifest = await source.parse(response);
      if (!isValidUpdateManifest(manifest)) throw new Error("The update manifest is invalid.");
      return manifest;
    } catch (error) {
      lastError = error;
      if (attempt === 0) await delay(450);
    }
  }
  throw lastError;
}

async function fetchUpdateManifest() {
  const results = await Promise.allSettled(
    UPDATE_MANIFEST_SOURCES.map((source, sourceIndex) => fetchManifestSource(source, sourceIndex)),
  );
  const manifests = results.filter((result) => result.status === "fulfilled").map((result) => result.value);
  if (!manifests.length) {
    const failedResult = results.find((result) => result.status === "rejected");
    throw failedResult?.reason || new Error("No update manifest source is available.");
  }
  return manifests.reduce((newest, manifest) => (
    compareVersions(manifest.latestVersion, newest.latestVersion) > 0 ? manifest : newest
  ));
}

async function ensureBundleDownloaded(LiveUpdate, manifest) {
  let lastError = new Error("Bundle download failed.");
  for (let attempt = 0; attempt < 3; attempt += 1) {
    const { bundleIds = [] } = await LiveUpdate.getBundles();
    if (bundleIds.includes(manifest.bundleId)) return;
    try {
      await LiveUpdate.downloadBundle({
        url: manifest.bundleUrl,
        bundleId: manifest.bundleId,
        checksum: manifest.sha256.toLowerCase(),
        artifactType: "zip",
      });
      return;
    } catch (error) {
      lastError = error;
      if (attempt < 2) await delay(700 * (attempt + 1));
    }
  }
  throw lastError;
}

async function disableNativeServiceWorker() {
  if ("serviceWorker" in navigator) {
    const registrations = await navigator.serviceWorker.getRegistrations().catch(() => []);
    await Promise.all(registrations.map((registration) => registration.unregister().catch(() => false)));
  }
  if ("caches" in window) {
    const cacheKeys = await caches.keys().catch(() => []);
    await Promise.all(cacheKeys.filter((key) => key.startsWith("sn-crm-")).map((key) => caches.delete(key).catch(() => false)));
  }
}

async function checkForLiveUpdate(force = false, userInitiated = false) {
  if (updateCheckRunning) {
    if (userInitiated) showToast(t("updateChecking"));
    return;
  }
  const plugins = getNativePlugins();
  if (!plugins) {
    if (userInitiated) showToast(t("updateIdle"));
    return;
  }
  const { LiveUpdate, Network } = plugins;
  if (!force && Date.now() - lastUpdateCheck < UPDATE_CHECK_INTERVAL_MS) return;
  updateCheckRunning = true;
  lastUpdateCheck = Date.now();
  try {
    const networkStatus = await Network.getStatus();
    if (!networkStatus.connected) {
      setUpdateStatus("updateOffline");
      if (userInitiated) showToast(t("updateOffline"));
      return;
    }
    setUpdateStatus("updateChecking");
    const manifest = await fetchUpdateManifest();
    if (compareVersions(manifest.latestVersion, APP_VERSION) <= 0) {
      setUpdateStatus("updateCurrent");
      if (userInitiated) showToast(t("updateCurrent"));
      return;
    }
    const { versionCode } = await LiveUpdate.getVersionCode();
    if (Number(versionCode) !== Number(manifest.nativeVersionCode)) {
      throw new Error("The update is not compatible with this native app version.");
    }
    const { bundleIds: blockedBundleIds = [] } = await LiveUpdate.getBlockedBundles();
    if (blockedBundleIds.includes(manifest.bundleId)) throw new Error("The update bundle is blocked after a rollback.");
    const { bundleId: currentBundleId } = await LiveUpdate.getCurrentBundle();
    const { bundleId: nextBundleId } = await LiveUpdate.getNextBundle();
    if (currentBundleId === manifest.bundleId) {
      setUpdateStatus("updateCurrent");
      if (userInitiated) showToast(t("updateCurrent"));
      return;
    }
    if (nextBundleId !== manifest.bundleId) {
      setUpdateStatus("updateDownloading");
      await ensureBundleDownloaded(LiveUpdate, manifest);
      await LiveUpdate.setNextBundle({ bundleId: manifest.bundleId });
    }
    if (state.role || state.view !== "login") {
      setUpdateStatus("updateQueued");
      if (userInitiated) showToast(t("updateQueued"));
      return;
    }
    setUpdateStatus("updateInstalling");
    await disableNativeServiceWorker();
    await LiveUpdate.reload();
    setUpdateStatus("updateQueued");
  } catch (error) {
    setUpdateStatus("updateFailed", error);
    if (userInitiated) showToast(t("updateFailed"));
  } finally {
    updateCheckRunning = false;
  }
}

async function initializeLiveUpdates() {
  const plugins = getNativePlugins();
  if (!plugins) return;
  const { LiveUpdate, Network } = plugins;
  try {
    const readyResult = await LiveUpdate.ready();
    if (readyResult?.rollback) setUpdateStatus("updateFailed", new Error("The previous update was rolled back."));
    await disableNativeServiceWorker();
    await checkForLiveUpdate(true);
    await Network.addListener("networkStatusChange", (status) => {
      if (status.connected) checkForLiveUpdate(true);
    });
  } catch (error) {
    setUpdateStatus("updateFailed", error);
  }
}

app.addEventListener("click", (event) => {
  const target = event.target.closest("[data-action]");
  if (!target) return;
  const action = target.dataset.action;
  if (action === "settings") openSettings();
  if (action === "close-settings") closeSettings();
  if (action === "check-update") checkForLiveUpdate(true, true);
  if (action === "logout") logout();
  if (action === "forgot-password") showToast(t("forgotMessage"));
  if (action === "navigate") navigateTo(target.dataset.view);
  if (action === "back-customer") backToCustomerHome();
  if (action === "demo-document") showToast(t("documentNotConnected"));
});

app.addEventListener("input", (event) => {
  if (event.target.id !== "customer-search") return;
  state.customerQuery = event.target.value;
  const list = document.getElementById("installer-customer-list");
  if (list) list.innerHTML = installerCustomerRows();
});

app.addEventListener("submit", (event) => {
  if (event.target.id === "login-form") {
    event.preventDefault();
    attemptLogin(event.target);
  }
  if (event.target.id === "account-form") {
    event.preventDefault();
    saveAccount(event.target);
  }
});

window.addEventListener("popstate", (event) => {
  if (event.state?.loggedIn && state.role) {
    state.view = event.state.view || homeViewForRole(state.role);
    renderWorkspace();
    return;
  }
  state.role = null;
  state.username = "";
  state.view = "login";
  renderLogin();
});

document.addEventListener("visibilitychange", () => {
  if (document.visibilityState === "visible") checkForLiveUpdate();
});

if ("serviceWorker" in navigator && !window.Capacitor?.isNativePlatform?.()) {
  window.addEventListener("load", () => navigator.serviceWorker.register("./service-worker.js").catch(() => {}));
}

readStoredData();
history.replaceState({ loggedIn: false }, "");
renderLogin();
initializeLiveUpdates();
