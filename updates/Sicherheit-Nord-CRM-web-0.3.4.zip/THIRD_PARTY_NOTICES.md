# Drittanbieterhinweise

Die im Errichterbereich angezeigten Namen stehen für öffentlich belegte Geschäftsbeziehungen mit Sicherheit Nord. Die daneben dargestellten Anlagenzahlen, Termine und Statuswerte sind ausschließlich Platzhalter für den Prototyp.

## BARMER

- Beziehung: EU-Vergabebekanntmachung 118700-2026, BARMER als Auftraggeber und SICHERHEIT NORD GmbH & Co. KG als Auftragnehmer.
- Logo: `barmer.svg`, BARMER-Wortmarke von Wikimedia Commons. Dort als gemeinfreie einfache Wort-/Bildmarke gekennzeichnet. Markenrechte bleiben unberührt.
- Quelle: https://commons.wikimedia.org/wiki/File:Barmer_Logo_12.2025.svg

## Physikalisch-Technische Bundesanstalt

- Beziehung: EU-Vergabebekanntmachung 544492-2026, Physikalisch-Technische Bundesanstalt als Auftraggeber und Sicherheit Nord GmbH & Co. KG als Auftragnehmer.
- Logo: `ptb.png`, erstellt und veröffentlicht von der Pressestelle der PTB unter CC BY-SA 4.0; unverändert verwendet.
- Quelle: https://commons.wikimedia.org/wiki/File:Physikalisch-Technische_Bundesanstalt_2013_logo.png
- Lizenz: https://creativecommons.org/licenses/by-sa/4.0/

Die Darstellung dient nur der Identifikation in einer internen Produktvorführung und stellt keine Empfehlung oder Freigabe der App durch die genannten Organisationen dar.
